<?php
    function nomor(){
        $nomor = "082277560385";
        return $nomor;

    }
?>